export const GlobalColors = {
    colors: {
        slateblue: `#3b3380`,
        slategray: `#708090`,
        lavender: `#e6e6fa`,
        mediumpurple: `#776ec4`,
        lightpurple: '#bda8f0',
        gold: '#daa520'
    },
}